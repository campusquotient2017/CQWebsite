
<!DOCTYPE html>
<html lang="en-US" prefix="og: http://ogp.me/ns#" class="no-js no-svg defaultHeader">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="INTERESTED INDUSTRY INTELLIGENCE WORKING TO BRIDGE THE GAP BETWEEN INDUSTRY AND ACADEMIA.">
 <link href="css/style.css" rel="stylesheet">
  <link href="fonts/font-awesome-css.min.css" rel="stylesheet">
   <script type="text/javascript" src="js/main.js" charset="UTF-8"></script><script src="https://use.fontawesome.com/6e31837b67.js"></script>
  <script src="js/jquery.min.js"></script>
  <link rel="shortcut icon" href="images/CQlogo.png" />
  
  <!-- FOR THE CAMPAIGN PAGE -->
  <link rel="stylesheet" type="text/css" href="https://cloud.typography.com/6372396/7550992/css/fonts.css" />

  
<!-- This site is optimized with the Yoast SEO plugin v5.9.1 - https://yoast.com/wordpress/plugins/seo/ -->
<title>Campus Quotient | About Campus Quotient -</title>
<link rel="canonical" href="AboutUs.php" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Campus Quotient | Homepage -" />
<meta property="og:url" content="https://CampusQuotient.org/" />
<meta property="og:site_name" content="Campus Quotient" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Campus Quotient | Homepage -" />
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"WebSite","@id":"#website","url":"https:\/\/CampusQuotient.org\/","name":"Acumen","potentialAction":{"@type":"SearchAction","target":"https:\/\/CampusQuotient.org\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"Organization","url":"https:\/\/CampusQuotient.org\/about\/","sameAs":[],"@id":"#organization","name":"Acumen","logo":"http:\/\/CampusQuotient.org\/wp-content\/uploads\/2017\/10\/logo-1.png"}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/CampusQuotient.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.1"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56794,8205,9794,65039],[55358,56794,8203,9794,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
		@font-face{
	 font-family:itc-avant-garde-gothic-std-bold-condensed;
	 src:url("fonts/itc-avant-garde-gothic-std-bold-589572c7e9955.otf");
}
body{
font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;
}

@font-face{
	 font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;
	 src:url("fonts/itc-avant-garde-gothic-std-extra-light-5895708744eb6.otf");
}
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-111977124-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-111977124-1');
</script>

<link rel='shortlink' href='' />
</head>

<body class="page-template-default page page-id-19997 page-parent" >
  <div id="MainNavDiv" class="sidenavMoves">
  <nav class="navbar navbar-expand-lg navbar-light bg-white" id="mainNav">
    <div class="container">
       <a class="navbar-brand" href="index.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;"><img src="images/CQlogo.png" alt="CQlogo"></a>
     <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button> -->

      <div class="collapse navbar-collapse" id="navbarsExample07">
        <div id="bs-example-navbar-collapse-1" class="collapse navbar-collapse"><ul id="menu-main-menu" class="nav navbar-nav" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="About" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu" >
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="About Us" href="AboutUs.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About Us</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Manifesto" href="Manifesto.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Manifesto</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Team" href="Team.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Team</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Partners" href="Partners.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Partners</a></li>
</ul>
</li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="Engage With Us" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Engage With Us <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu" >
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="Students" href="EngageWithUs.php#student" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Students</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Professors" href="EngageWithUs.php#professors" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Professors</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Corporate Partners" href="EngageWithUs.php#corporate" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Corporate Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Government of India" href="EngageWithUs.php#GOI" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Government of India</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Training Partners" href="EngageWithUs.php#training" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Training Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Volunteers" href="EngageWithUs.php#volunteers" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Volunteers</a></li>

	</ul>
</li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="The Latest" href="Latest.php">Latest</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="Gallery" href="Gallery.php">Gallery</a></li>
</ul></div>        </div>


        <div class="button-area">
          
          <a href="donation.php" target="_blank" class="btn primary heroDonateButton" style=" font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
            Contribute
            <span></span>
          </a>


        <button class="js-toggle-sidenav menu-btn">
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
    </div>
  </nav>
  <span id="navBorder"></span>
  <form id="headerSearchBox" class="form-inline my-md-0 search-area " method="get" action="https://CampusQuotient.org" role="search">
    <div class="inner">
      <div class="container">
        <a class="navbar-brand" href="index.php"><img src="images/CQlogo.png" alt="CQlogo"></a>

        <div class="searchBox" id="searchBox">
          <input class="form-control" type="search" placeholder="WHAT ARE YOU LOOKING FOR?" onfocus="this.placeholder = ''" onblur="this.placeholder = 'WHAT ARE YOU LOOKING FOR?'" value="" name="s" title="Search for:" aria-label="Search">
          <button class="icon-btn" type="submit" role="button">
            <svg width="22px" height="22px" viewBox="0 0 22 22" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Main-Nav-01" transform="translate(-1199.000000, -39.000000)">
            <g id="Search-icon" transform="translate(1200.000000, 40.000000)">
                <rect id="Rectangle-24" fill="#716B70" transform="translate(16.242641, 16.742641) rotate(45.000000) translate(-16.242641, -16.742641) " x="11.2426407" y="16.2426407" width="10" height="1"></rect>
                <circle id="Oval" stroke="#716B70" cx="7.5" cy="7.5" r="7.5"></circle>
            </g>
        </g>
    </g>
</svg>          </button>
        </div>

        <a class="search-close-btn" href="/"><svg width="23px" height="21px" viewBox="0 0 23 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    
</svg></a>
      </div>
    </div>
  </form>
</div>
<div id="stickySpacer"></div>

<div id="mainContainer" class="sidenavMoves">
  <div id="slideContent">
<div class="jumbotron simple-header add-slash" style="background: url(images/library-869061_960_720.jpg); background-size: cover; background-position: center center;">
		<div class="container">
		<div class="row">
			<div class="col-md-7"></div>
			<div class="col-md-5 float-right z-9 align-self-center">
				<div class="hero-content">
					<div class="h2 text-white fadeInBlock animated"><p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"><strong style="font-family:itc-avant-garde-gothic-std-bold-condensed;">Interested Industry Intelligence</strong> working to bridge the gap between Industry and Academia.</p>
</div>
								    </div>
			</div>
		</div>
	</div>
	</div>


	
<div class="type_settings  " >
			<div class="container ">
			<div class="row">
				<div class="col-md-6">
					<div class="h2 featured-text"><p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"><strong style="font-family:itc-avant-garde-gothic-std-bold-condensed; color:#0085c3;">WE BELIEVE EVERY INDIVIDUAL POSSESSES CALIBRE </strong>ONLY LACKS THE  CHANNEL.</p>
</div>
				</div>
				<div class="col-md-6">
					<br/><p class="section-title" style="font-family:itc-avant-garde-gothic-std-bold-condensed; ">
						<font size="6" color="#0085c3">OUR VISION</font>					</p>
					<div class="body_text"><p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Transform Indian educational campuses to technology and innovation hubs, optimising their existing infrastructure & next-gen talent viz., software engineers, faculty and mentors; to sustain the needs of the industry; thus improving employability, exponentially.</p>
</div>
											
									</div>
			</div>
		</div>
	
	
	
	</div>	
		<div class="homepage-leftright block  right-image-first  from-template fadeInRightBlock animated greybg" data-aos="fade-up" data-aos-anchor-placement="top-center" data-aos-once="true">
				<div class="container">
					<div class="row ">
						<div class="col-md-6  align-self-center text-side">
							<span class="pink-text small-text uppercase"></span>
							<div class="h2" style=" font-family:itc-avant-garde-gothic-std-bold-condensed; color:#0085c3;">Our Story</div>
							<div class="body_text"><p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">CQ was incorporated on 19th October 2016 with zero capital and 6 techies. Our motto was to give back to the society by reducing unemployment and underemployment. We started our journey from Karnataka, India and went into the colleges, producing young talents to nurture their skills by making them enterprise ready while in campus. During this journey we were blessed to receive support from one of the largest educational governing body in India, AICTE. Currently focused and working relentlessly towards achieving the vision of making India’s workforce an exemplary one equipped with superlative knowledge, skill and work culture.</p>
</div>
															
													</div>
						<div class="col-md-6 image-side">
							<div class="">
								<img src="images/books.jpg" alt="OurStory" class="">
							</div>
						</div>
					</div>
				</div>
			</div>

		
		<div class="homepage-leftright block  left-image-first  from-template fadeInRightBlock animated greybg" data-aos="fade-up" data-aos-anchor-placement="top-center" data-aos-once="true">
				<div class="container">
					<div class="row ">
						<div class="col-md-6  align-self-center text-side">
							<span class="pink-text small-text uppercase"></span>
							<div class="h2" style="font-family:itc-avant-garde-gothic-std-bold-condensed;color:#0085c3;">Our Partners</div>
							<div class="body_text"><p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"> When we first began, our goal was our guiding. As the universe would have it, we met fellow fraternity members from the Industry who shared the same vision. We were lucky to have AICTE supporting this little ship of ours in driving this initiative removing the initial roadblocks we had. Many start-ups and industry giants came forward to handhold with us and still continue to extend their support to us. We always look forward to more such partners who wish to make a major change in the educational systems and would be privileged to have such enterprises onboard with us.</p>
</div>
															<a href="contactform.php" class="btn primary" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
									Join Us									<span></span>
								</a>
													</div>
						<div class="col-md-6 image-side">
							<div class="">
								<img src="images/corp.jpg" alt="OurPartners" class="">
							</div>
						</div>
					</div>
				</div>
			</div>

		
		
	
<div class="type_settings  "  data-aos="fade-up" data-aos-anchor-placement="top-center" data-aos-once="true" >
	
			<div class="container  ">
			<div class="row">
								<div class="title-box col-md-12">
					<div class="h2"><center><p style=" font-family:itc-avant-garde-gothic-std-bold-condensed;color:#0085c3;">WHAT WE DO</p></center>
</div>
				</div>
																																																	<div class="col-md-4 three-wide type-box " >
																													<div class="image-box" style="background-image:url(images/img1.jpg); background-position: center; background-size: cover;" ></div>
														<div class="box-content  has-image" >
								
																<p class="section-title" style="font-family:itc-avant-garde-gothic-std-bold-condensed; align:left;">
									We make students enterprise              <br/> ready while in campus							</p>
																		
															</div>
						</div>
																																									<div class="col-md-4 three-wide type-box ">
																													<div class="image-box" style="background-image:url(images/img3.jpeg); background-position: center; background-size: cover;"></div>
														<div class="box-content  has-image">
								
																<p class="section-title" style="font-family:itc-avant-garde-gothic-std-bold-condensed; align:left;">
Alumni-buddy-connect</p>
																
																	
															</div>
						</div>
																																									<div class="col-md-4 three-wide type-box ">
																													<div class="image-box" style="background-image:url(images/inno.jpg); background-position: center; background-size: cover;"></div>
														<div class="box-content  has-image">
								
																<p class="section-title" style="font-family:itc-avant-garde-gothic-std-bold-condensed; align:left;">
									Promote innovations through Ideaken							</p>
																
																	
															</div>
						</div>
						<div class="col-md-4 three-wide type-box ">
																													<div class="image-box" style="background-image:url(images/img2.jpeg); background-position: center; background-size: cover;"></div>
														<div class="box-content  has-image">
								
																<p class="section-title" style="font-family:itc-avant-garde-gothic-std-bold-condensed; align:left;">
									Bring industry into institutions							</p>
																		
															</div>
						</div>
						<div class="col-md-4 three-wide type-box ">
																													<div class="image-box" style="background-image:url(images/partnership.jpg); background-position: center; background-size: cover;"></div>
														<div class="box-content  has-image">
								
																<p class="section-title" style="font-family:itc-avant-garde-gothic-std-bold-condensed; align:left;">
									HELP CORPORATES TO FIND<br/>THE RIGHT TALENTS							</p>
																		
															</div>
						</div><div class="col-md-4 three-wide type-box ">
																													<div class="image-box" style="background-image:url(images/img6.jpeg); background-position: center; background-size: cover;"></div>
														<div class="box-content  has-image">
								
																<p class="section-title" style="font-family:itc-avant-garde-gothic-std-bold-condensed; align:left;">
										RESKILLING OF TALENTS TO MEET <br/>THE CHANGING NEEDS OF THE <br/>INDUSTRY						</p>
																		
															</div>
						</div>
						<div class="col-md-4 three-wide type-box ">
																													<div class="image-box" style="background-image:url(images/intern.jpg); background-position: center; background-size: cover;"></div>
														<div class="box-content  has-image">
								
																<p class="section-title" style="font-family:itc-avant-garde-gothic-std-bold-condensed; align:left;">
										PROVIDE OPPORTUNITIES TO THE <br/>DESERVING						</p>
																		
															</div>
						</div>
						<div class="col-md-4 three-wide type-box ">
																													<div class="image-box" style="background-image:url(images/img7.jpeg); background-position: center; background-size: cover;"></div>
														<div class="box-content  has-image">
								
																<p class="section-title" style="font-family:itc-avant-garde-gothic-std-bold-condensed; align:left;">
									PROMOTE WOMEN EMPOWERMENT<br/>  AND ENTERPRENEURSHIP						</p>
																		
															</div>
						</div>
						<div class="col-md-4 three-wide type-box ">
																													<div class="image-box" style="background-image:url(images/school-2761394_1280.jpg); background-position: center; background-size: cover;"></div>
														<div class="box-content  has-image">
								
																<p class="section-title" style="font-family:itc-avant-garde-gothic-std-bold-condensed; align:left;">
SKILL THE UNDERPRIVILEGED AND <br/>HELP THEM TO BUILD A <br/>CAREER OF THEIR OWN								</p>
																		
															</div>
						</div>
												</div>
		</div>
	
	
	</div>
	
<style>
.type_settings .image-box{
	height: 90px;
	width:90px;
}
</style>

				<footer >
			<div class="container">
				<div class="row text-left">
					<div class="col-md-12">
						<h2 class="text-white" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Get Our Newsletter To Stay Up To Date</h2>
						<form class="form1" method='post' action="">
						<input type="email" name="emailid" placeholder="email here" required />
						<button name="submit"> SUBSCRIBE </button>
						</form>
						<?php
							error_reporting(0);
							include_once 'connect_db.php';
							if(isset($_SESSION['user'])!="")
							{
								header("Location: AboutUs.php");
							}
							if(isset($_POST['submit']))
							{
								
					
								$email = mysql_real_escape_string($_POST['emailid']);
								$query=mysql_query("SELECT * FROM subscribers WHERE EmailId='".$email."'"); 
								$numrows=mysql_num_rows($query);  
								if($numrows!=0) 
								{	
									?>
									<script>alert('Already an existing subscriber !!! ');</script>
									<?php
								}	
								else								
								{
								 if(mysql_query("INSERT INTO subscribers(EmailId) VALUES('$email')"))
								{
									?>
									<script>alert('Successfully Subscribed !!! ');</script>
									<?php
								}
								else
								{
									?>
									<script>alert('error while submitting your details...');</script>
									<?php
								}
								}
							}
						?>
                        </div>
						<style>
						.form1{
							width:100%;
						height:50px;}
						form input{
							width:300px;
							height:50px;
							background-color:white;
							border:none;
							border-top-left-radius:5px;
						border-bottom-right-radius:5px;}
						form input[type="email"]{
							padding-left:10px;
							
						}
						button{
							height:55px;
							background-color:#999;
							color:#333;
							padding-left:10px;
							padding-right:10px;
							border:1px solid #333;
							border-top-left-radius:5px;
							border-bottom-right-radius:5px;
							transition: all0 0.5s ease-in-out;
						}
						button:hover{
							background-color:#333;
						color:#999;}
						</style>
					</div>
				</div>
				
				<div class="row bottom-section">
					<div class="col-md-2">
						<img src="images/CQlogo.png" alt="CQlogo" class="footer-logo" width="100" height="70"><br/><br/>
						<i class="fa fa-phone" aria-hidden="true" style="color:white;"></i>&nbsp;&nbsp;<font color="white">+91 9632283007</font>
					</div>
					<div class="col-md-10">
						<div class="topnav">
							<ul>
								
								<li>
									<a href="contactform.php" class="btn secondary" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
										<span></span>
										Contact Us
									</a>
								</li>
								<li class="social-button">
					                 <a href="https://www.facebook.com/CampusQuotient/?fref=nf" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
					            </li>
					            <li class="social-button">
					                <a href="https://twitter.com/CampusQuotient" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
					            </li>
					            <li class="social-button">
					                 <a href="https://www.youtube.com/channel/UC8O5Yr5n6qJ3JcigfOAN80g" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a>
					            </li><li class="social-button">
					                 <a href="https://www.linkedin.com/company/campus-quotient" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
					            </li>
								<li class="social-button">
					                 <p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:160%;color:white;"><b>&nbsp;&nbsp;&nbsp;&nbsp;CAMPUS QUOTIENT FOUNDATION </b></p>
					            </li>
					        </ul>
						</div>
						
					</div>
				</div>
			</div>
		</footer>
		<span id="view-profile-overlay">
			<a href="#" class="close-profile">
				<svg width="82px" height="82px" viewBox="0 0 82 82" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
   
</svg>			</a>
		</span>
	</div><!-- End of #slideContent -->
</div><!-- End of #mainContainer -->

<div id="sidenavContainer" off-canvas="sidenav right shift">
	<div class="inner">       
    <a href="#" class="js-toggle-sidenav">
        <svg width="23px" height="21px" viewBox="0 0 23 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="CQ-Website-v2-Final" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="square">
        <g id="Navigation-1---Burger-Tray-B" transform="translate(-901.000000, -40.000000)" stroke="#FFFFFF">
            <g id="X" transform="translate(902.000000, 40.000000)">
                <path d="M0,0 L20.9632932,20.9632932" id="Line"></path>
                <path d="M0,20.9632932 L20.9632932,0" id="Line-Copy-2"></path>
            </g>
        </g>
    </g>
</svg>    </a>

    <div class="mobile-sideNav">
			<div class="mobile-side">
				  <ul id="menu-main-menu" class="nav navbar-nav" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
					<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="About" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About <span class="caret"></span></a>
						<ul role="menu" class=" dropdown-menu" >
							<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="About Us" href="AboutUs.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About Us</a></li>
							<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Manifesto" href="Manifesto.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Manifesto</a></li>
							<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Team" href="Team.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Team</a></li>
							<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Partners" href="Partners.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Partners</a></li>
						</ul>
					</li>
					<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="Engage With Us" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Engage With Us <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu" >
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="Students" href="EngageWithUs.php#student" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Students</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Professors" href="EngageWithUs.php#professors" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Professors</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Corporate Partners" href="EngageWithUs.php#corporate" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Corporate Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Government of India" href="EngageWithUs.php#GOI" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Government of India</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Training Partners" href="EngageWithUs.php#training" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Training Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Volunteers" href="EngageWithUs.php#volunteers" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Volunteers</a></li>

	</ul>
</li><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="The Latest" href="Latest.php">Latest</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="Gallery" href="Gallery.php">Gallery</a></li>
				</ul>
		</div>    
	</div>
   <div class="bottom-section">
        <div class="links">
            <div class="link-item active">
                
                <div class="form-box">
                     <div class="class-area">
                        <div class="course-image" style="background: url(images/Section4.jpeg); background-position: center; background-size: cover;height:300px;"></div>
                        
							<a href="AboutUs.php" target="_blank" class="btn secondary" style="font-size:13px;">Add CQ courses to your curriculum</a>
                    </div>
                </div>
            </div>
			<div class="link-item">
                 <a href="contactform.php" class="text-box right">
                            Apply To Us                      </a>
            </div>
            <div class="link-item">
                <a href="Partners.php" class="text-box right">
                            Partner With Us                        </a>
            </div>
           
            <div class="link-item">
                <a href="donation.php" class="text-box right">
                           Other ways to give                     </a>
            </div>
                            
            
        </div>

        <div class="social_links">
                            <ul class="social-icons">
                                    <li class="social-button">
                        <a href="https://www.facebook.com/CampusQuotient/?fref=nf"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    </li>
                                    <li class="social-button">
                        <a href="https://twitter.com/CampusQuotient"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    </li>
                                    <li class="social-button">
                        <a href="https://www.youtube.com/channel/UC8O5Yr5n6qJ3JcigfOAN80g"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                    </li><li class="social-button">
					                 <a href="https://www.linkedin.com/company/campus-quotient" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
					            </li>
                                </ul>
                    </div>
    </div>
</div></div>


<div id="profileContainer" off-canvas="view-profile right shift">
	<div id="profile"></div>
	<a href="#" class="close-profile">
		<svg width="82px" height="82px" viewBox="0 0 82 82" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    
</svg>	</a>
</div>


<!-- JS -->
<script src='js/jquery-ui.min.js'></script>
<script src="js/acumen.min.js"></script>
<link rel='stylesheet' id='gravityformsmailchimp_form_settings-css'  href='css/form_settings.css' type='text/css' media='all' />
<script type='text/javascript' src='js/wp-embed.min.js'></script>
<script type='text/javascript' src='js/jquery.js'></script>
<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
<script type='text/javascript' src='js/jquery.json.min.js'></script>
<script type='text/javascript' src='js/gravityforms.min.js'></script>
<script type='text/javascript' src='js/placeholders.jquery.min.js'></script>

</body>
</html>
