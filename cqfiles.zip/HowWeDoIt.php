
<!DOCTYPE html>
<!--[if lt IE 9 ]>    <html class="lt-ie9 no-js"  lang="en" dir="ltr"> <![endif]-->
<!--[if gte IE 9]><!--> 
<html class="no-js"  lang="en" dir="ltr"  prefix="fb: http://www.facebook.com/2008/fbml
 og: http://ogp.me/ns#
 article: http://ogp.me/ns/article#
 book: http://ogp.me/ns/book#
 profile: http://ogp.me/ns/profile#
 video: http://ogp.me/ns/video#
 product: http://ogp.me/ns/product#
 content: http://purl.org/rss/1.0/modules/content/
 dc: http://purl.org/dc/terms/
 foaf: http://xmlns.com/foaf/0.1/
 rdfs: http://www.w3.org/2000/01/rdf-schema#
 sioc: http://rdfs.org/sioc/ns#
 sioct: http://rdfs.org/sioc/types#
 skos: http://www.w3.org/2004/02/skos/core#
 xsd: http://www.w3.org/2001/XMLSchema#
"> <!--<![endif]-->
  <head>
    <meta charset="utf-8" />
<link rel="shortcut icon" href="images/CQlogo.png" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="CAMPUS QUOTIENT, THE FAVOURITE SCHOOL FOR IMPACTFUL CHANGE">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<link rel="canonical" href="HowWeDoIt.php">
 
<!-- Google Tag Manager -->
<script type="text/javascript" src="js/main.js" charset="UTF-8"></script>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MRPM3QM');</script>
<!-- End Google Tag Manager --><meta name="generator" content="Drupal 7 (http://drupal.org)" />

<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','//connect.facebook.net/en_US/fbevents.js');

fbq('init', '1682998915312969');
fbq('track', 'PageView');
</script>
<noscript><img height='1' width='1' style='display:none' src='images/CQlogo.png'alt="CQlogo" /></noscript>
<!-- End Facebook Pixel Code -->
    <title>Home | Campus Quotient</title>

    <link rel="stylesheet" href="css/css_xE-rWrJf-fncB6ztZfd2huxqgxu4WO-qwma6Xer30m4.css" />
<link rel="stylesheet" href="css/css_ZwQ4JegYk9_vB7LtvEKjfjeVcLzDAa88SNWeshZo5Jw.css" />
<link rel="stylesheet" href="css/css_58ExTv_gjpjLAzGO-FU70kxmc1PEecpAS1OmAM54kqc.css" />
<link rel="stylesheet" href="css/css_PUa76jPWUBgb6o5tA1FUfhozHRVWDB7134qJhw4UL_8.css" />
<link rel="stylesheet" href="css/css_H09PZPGmLrSUCGGE2lab6TvYJFk_Mzo2D5fudP2rZZ0.css" />
<style>
@font-face{
	 font-family:itc-avant-garde-gothic-std-bold-condensed;
	 src:url("fonts/itc-avant-garde-gothic-std-bold-589572c7e9955.otf");
}


@font-face{
	 font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;
	 src:url("fonts/itc-avant-garde-gothic-std-extra-light-5895708744eb6.otf");
}
</style>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-111977124-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-111977124-1');
</script>

    <script src="js/js_WkOMkSyjg9rxsesVK2mUAVX_dhZTWbIE6jpIzuL-ygM.js"></script>
<script src="js/js_zfknOK6Pz34lw30Xsm5toXF4sk5yxEBB-TzI9ylO60s.js"></script>
<script src="js/js_rX7syLXSIEZQF14zvqhF7tcUCvJvVaWRXpJWh85q41g.js"></script>
<script src="js/js_p9WjUDpJdXbceWFpHfkKh0VdJ5GsDrpQSql_WFBL6c4.js"></script>
 </head>
  <body class="html front not-logged-in no-sidebars page-home" >
    <div id="skip-link">
      <a href="#main" class="element-invisible element-focusable" role="link" style="font-family:AvantGardeLT-BookObliqueimport;">Skip to main content</a>
    </div>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MRPM3QM"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --> 

  <header style="position: relative; background-color: transparent;padding: 0px 20px 10px; background: url(images/invert.png); background-size: 100% 100%; background-position: center center;">
    
        <span id="logo">
			<a href="index.php" title="Campus Quotient" rel="home" style="margin-left:30px; margin-top:5px;">
			<img  src="images/CQlogo.png" alt="CQlogo" />  </a>
		</span>
    
  </header>


  <main id="main" role="main" class="main" >
    <div id="main-content-container" class="region-inner">
        <div id="block-system-main" class="block block-system">

    
  <div class="content" >
    <div class="panel-display panel-1col clearfix" >
      <div class="region region-1col-fullwidth_hero">
        <div class="region-inner pane-content">
          <div class="panel-pane pane-fieldable-panels-pane pane-vid-257 pane-bundle-hero-slideshow--single pane-bundle-hero-slideshow pane-fpid-27"  >
  
      
  
  <div class="pane-content"  >
    <div class="pane-content-inside">
      <div class="fieldable-panels-pane">
    <div class="slick slick--less slick--optionset--hero-slideshow unslick" id="slick-fieldable-panels-pane-27-hero-slideshow-field-slideshow-slide-1">
  
          <div class="slick__slide slide slide--0" >            <div class="slide__media">      <div class="media media--image" > <img typeof="foaf:Image" src="" width="2200" height="650"><img src="images/bannerimg.jpeg" alt="banner" width="2000"/></div>            </div>
                      <div class="slide__caption">
          
                      
            
            
                          <div class="slide__description"><h3 style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"><strong style="font-family:itc-avant-garde-gothic-std-bold-condensed;">CAMPUS QUOTIENT</strong>, THE FAVOURITE SCHOOL FOR <strong style="font-family:itc-avant-garde-gothic-std-bold-condensed;">IMPACTFUL CHANGE</strong></h3>
            
            
                              </div>
              
      </div>    
  </div>
</div>
    </div>
  </div>

  
  </div>
        </div>
    </div>
  
  
      <div class="panel-panel panel-col panel-col-bottom">
      <div class="region-inner pane-content">
        <div class="panel-pane pane-fieldable-panels-pane pane-vid-261 pane-bundle-course-reference pane-fpid-28"  >
  
        <h2 class="pane-title" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
      <strong style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Courses</strong> at a glance    </h2>
    
  
  <div class="pane-content">
    <div class="pane-content-inside">
      <div class="fieldable-panels-pane">
	  <img src="images/Banner5.png" width="100%" alt="courses"/>
   </div>
    </div>
  </div>

  
  </div>

<div class="panel-pane pane-fieldable-panels-pane pane-vid-54 pane-bundle-cta-button pane-fpid-29"  >
  
      
  
<div class="pane-content">
    <div class="pane-content-inside">
      <div class="fieldable-panels-pane">
    <div class="field field-name-field-cta-link field-type-link-field field-label-hidden"></div></div>
    </div>
  </div>

  
  </div>



<div class="panel-pane pane-custom pane-1"  >
  
        <h2 class="pane-title" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
      OUR <strong style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">STUDENTS</strong>    </h2>
    
  
  <div class="pane-content">
    <div class="pane-content-inside">
      <p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Our students are tackling challenges in employability in many different ways.Here are just some of the places where they are from.</p>
    </div>
  </div>

  
  </div>

<div class="panel-pane pane-fieldable-panels-pane pane-vid-235 pane-bundle-image-and-content-area pane-fpid-30"  >
  
      
  
  <div class="pane-content">
    <div class="pane-content-inside">
      <div class="fieldable-panels-pane">
    <div class="field field-name-field-image-and-content-item field-type-field-collection field-label-hidden"><div class="field-items"><div class="field-item even"><div class="field field-name-field-image field-type-image field-label-hidden"><div class="field-items"><div class="field-item even"><img typeof="foaf:Image" src="images\alliance.jpg" alt="aliance" width="230" height="96" /></div></div></div></div><div class="field-item odd"><div class="field field-name-field-image field-type-image field-label-hidden"><div class="field-items"><div class="field-item even"><img typeof="foaf:Image" src="images\SILICON.PNG" alt="silicon" width="244" height="107" /></div></div></div></div><div class="field-item even"><div class="field field-name-field-image field-type-image field-label-hidden"><div class="field-items"><div class="field-item even"><img typeof="foaf:Image" src="images\symbiosis.png" alt="symbiosis" width="220" height="85" /></div></div></div></div><div class="field-item odd"><div class="field field-name-field-image field-type-image field-label-hidden"><div class="field-items"><div class="field-item even"><img typeof="foaf:Image" src="images\velhightech.png" alt="velhightech" width="230" height="96" /></div></div></div></div><div class="field-item even"><div class="field field-name-field-image field-type-image field-label-hidden"><div class="field-items"><div class="field-item even"><img typeof="foaf:Image" src="images\KLN.jpg" alt="KLN" width="230" height="96" /></div></div></div></div><div class="field-item odd"><div class="field field-name-field-image field-type-image field-label-hidden"><div class="field-items"><div class="field-item even"><img typeof="foaf:Image" src="images\vikram.png" alt="vikram" width="230" height="96" /></div></div></div></div></div></div></div>
    </div>
  </div>

  
  </div>

<div class="panel-pane pane-custom pane-2"  >
  
      
  
  <div class="pane-content">
    <div class="pane-content-inside">
      <p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Affiliations for identification only.</p>
    </div>
  </div>

  
  </div>

<div class="panel-pane pane-fieldable-panels-pane pane-vid-255 pane-bundle-fullwidth-hero-pane pane-fpid-31"  >
  
      
  
  

  
  </div>


      </div>
    </div>
  
    <div class="clearfix"></div>
    <div class="region region-1col-fullwidth_bottom" style="background: url(images/apply.jpeg); background-size: cover; background-position: center center;">
      <div class="region-inner pane-content">
        <div class="panel-pane pane-fieldable-panels-pane pane-vid-229 form-assembly-footer-form pane-bundle-embedded-formassembly-form pane-fpid-2"  >
  
      
  
  <div class="pane-content" >
    <div class="pane-content-inside">
      <div class="fieldable-panels-pane">
		<div class="field field-name-field-pre-form-content field-type-text-long field-label-hidden">
			<div class="field-items">
				<div class="field-item even"><h3 style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Interested? <strong style="font-family:itc-avant-garde-gothic-std-bold-condensed;;">Then Apply...</strong></h3>
				
				</div>
				<br/>
				<div class="view-footer" style="color:white;">
      <p class="align-center"><a href="contactform.php" class="button" style="color:white;font-family:itc-avant-garde-gothic-std-bold-condensed;"><b>Apply</b></a></p>
    </div>
		</div>
  

</div>
    </div>
  </div>

  
  </div>
      </div>
    </div>
  </div>


  </div>
</div>
    </div>
  </main>



	


<footer id="footer" role="contentinfo" class="footer" >
  <div class="region-inner">
          <div class="footer-left" >
			<div id="block-block-1" class="block block-block">
				<div class="content">
					<p><a href="index.php"><img alt="" src="images/CQlogo.png" alt="CQlogo" width="100" height="70"/></a></p>
				</div>
			</div>
			</div>
              <div class="footer-center" style="s margin-left:300px;">
				<div id="block-menu-menu-footer-internal-links" class="block block-menu" style="width:100%;">
					<div class="content" align="left">
						<p  style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6; font-size:30px;"> CAMPUS QUOTIENT FOUNDATION </p> 
					</div>
				</div>
				
			</div>
            <div class="footer-right">
			
				<div id="block-block-2" class="block block-block">
					<div class="content">
						<p><a href="" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">mailus@campusquotient.org</a><br /><a href="tel:+91 9632283007">+91 9632283007</a></p>
					</div>
				</div>
			</div>
   </div>
</footer>

    <script src="js/js_MLVgtzZ1ORq9krYqkeOsRay6ou_T-0QZytivuM9tTT8.js"></script>
  </body>
</html>
