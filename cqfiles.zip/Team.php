

<!DOCTYPE html>
<html lang="en-US" prefix="og: http://ogp.me/ns#" class="no-js no-svg defaultHeader">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="description" content="AN ENERGISED GROUP OF INDUSTRY VETERANS, PASSIONATE ABOUT THE CAUSE, DILIGENT TOWARDS THE TASK AND FOCUSSED ON THE TARGET.">
  <script type="text/javascript" src="js//main.js" charset="UTF-8"></script><script src="js/6e31837b67.js"></script>
  <script src="js/jquery.min.js"></script>
   <link rel="shortcut icon" href="images/CQlogo.png" />
 <link rel="canonical" href="Team.php">
 
  <!-- FOR THE CAMPAIGN PAGE -->
  <link rel="stylesheet" type="text/css" href="https://cloud.typography.com/6372396/7550992/css/fonts.css" />

  
<!-- This site is optimized with the Yoast SEO plugin v5.9.1 - https://yoast.com/wordpress/plugins/seo/ -->
<title>Campus Quotient| Team -</title>
<!-- / Yoast SEO plugin. -->
<link href="css/style.css" rel="stylesheet">
  <link href="fonts/font-awesome-css.min.css" rel="stylesheet">
  
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/CampusQuotient.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.1"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56794,8205,9794,65039],[55358,56794,8203,9794,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
		@font-face{
	 font-family:itc-avant-garde-gothic-std-bold-condensed;
	 src:url("fonts/itc-avant-garde-gothic-std-bold-589572c7e9955.otf");
}
body{
font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;
}

@font-face{
	 font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;
	 src:url("fonts/itc-avant-garde-gothic-std-extra-light-5895708744eb6.otf");
}
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-111977124-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-111977124-1');
</script>

</head>

<body class="page-template page-template-t-our-team page-template-t-our-team-php page page-id-19234 page-parent" >
  <div id="MainNavDiv" class="sidenavMoves">
  <nav class="navbar navbar-expand-lg navbar-light bg-white" id="mainNav">
    <div class="container">
        <a class="navbar-brand" href="index.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;"><img src="images/CQlogo.png" alt="CQlogo"></a>
    <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button> -->

      <div class="collapse navbar-collapse" id="navbarsExample07">
        <div id="bs-example-navbar-collapse-1" class="collapse navbar-collapse"><ul id="menu-main-menu" class="nav navbar-nav" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="About" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu" >
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="About Us" href="AboutUs.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About Us</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Manifesto" href="Manifesto.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Manifesto</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Team" href="Team.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Team</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Partners" href="Partners.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Partners</a></li>
</ul>
</li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="Engage With Us" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Engage With Us <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu" >
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="Students" href="EngageWithUs.php#student" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Students</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Professors" href="EngageWithUs.php#professors" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Professors</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Corporate Partners" href="EngageWithUs.php#corporate" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Corporate Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Government of India" href="EngageWithUs.php#GOI" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Government of India</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Training Partners" href="EngageWithUs.php#training" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Training Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Volunteers" href="EngageWithUs.php#volunteers" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Volunteers</a></li>

	</ul>
</li><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="The Latest" href="Latest.php">Latest</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="Gallery" href="Gallery.php">Gallery</a></li>

</ul></div>        </div>


        <div class="button-area">
         

          <a href="donation.php" target="_blank" class="btn primary heroDonateButton" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
            Contribute
            <span></span>
          </a>


          <button class="js-toggle-sidenav menu-btn">
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
    </div>
  </nav>
  <span id="navBorder"></span>
  <form id="headerSearchBox" class="form-inline my-md-0 search-area " method="get" action="" role="search">
    <div class="inner">
      <div class="container">
        <a class="navbar-brand" href="index.php"><img src="images/CQlogo.png" alt="CQlogo"></a>

        <div class="searchBox" id="searchBox">
          <input class="form-control" type="search" placeholder="WHAT ARE YOU LOOKING FOR?" onfocus="this.placeholder = ''" onblur="this.placeholder = 'WHAT ARE YOU LOOKING FOR?'" value="" name="s" title="Search for:" aria-label="Search">
          <button class="icon-btn" type="submit" role="button">
            <svg width="22px" height="22px" viewBox="0 0 22 22" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Main-Nav-01" transform="translate(-1199.000000, -39.000000)">
            <g id="Search-icon" transform="translate(1200.000000, 40.000000)">
                <rect id="Rectangle-24" fill="#716B70" transform="translate(16.242641, 16.742641) rotate(45.000000) translate(-16.242641, -16.742641) " x="11.2426407" y="16.2426407" width="10" height="1"></rect>
                <circle id="Oval" stroke="#716B70" cx="7.5" cy="7.5" r="7.5"></circle>
            </g>
        </g>
    </g>
</svg>          </button>
        </div>

        <a class="search-close-btn" href="/"><svg width="23px" height="21px" viewBox="0 0 23 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    
</svg></a>
      </div>
    </div>
  </form>
</div>
<div id="stickySpacer"></div>

<div id="mainContainer" class="sidenavMoves">
  <div id="slideContent">

<div class="jumbotron simple-header add-slash" style="background: url(images/team.jpg); background-size: cover; background-position: center center;">
		<div class="container">
		<div class="row">
			<div class="col-md-7"></div>
			<div class="col-md-5 float-right z-9 align-self-center" >
				<div class="hero-content">
					<div class="h2 text-white fadeInBlock animated"><p class="p1" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"><span class="s1"><strong style="font-family:itc-avant-garde-gothic-std-bold-condensed;">AN ENERGISED GROUP OF INDUSTRY VETERANS, </strong> PASSIONATE ABOUT THE CAUSE, DILIGENT TOWARDS THE TASK AND FOCUSSED ON THE TARGET.</span></p>
</div>
								    </div>
			</div>
		</div>
	</div>
	</div>











<div class="filter-area mobile-filter">
	<div class="container">
		<div id="teamSelect" class="select mobile-select" name="team">
			<div class="selected" >OUR TEAM</div>
			<div class="options hide">
				<div class="select-option view-cat link-out active" href="">Our Team</div>


				<div class="select-option view-cat link-out " href="">Board</div>


				<div class="select-option view-cat link-out " href="">Advisors</div>


				<div class="select-option view-cat link-out " href="">Investment Committees</div>
			</div>
		</div>
	</div>
</div>

<div class="tab-area">
	<div class="container">

		<a href="Team.php" class="view-cat" >
			<div class="slant-tab active">
				<span>Our Team</span>
			</div>
		</a>
		<!--<a href="https://CampusQuotient.org/our-team/board/" class="view-cat " >
			<div class="slant-tab ">
				<span>Board</span>
			</div>
		</a>
		<a href="https://CampusQuotient.org/our-team/advisors/" class="view-cat ">
			<div class="slant-tab ">
				<span>Advisors</span>
			</div>
		</a>
		<a href="https://CampusQuotient.org/our-team/investment-committees/" class="view-cat " >
			<div class="slant-tab ">
				<span>Investment Committees</span>
			</div>
		</a>-->
	</div>
</div>



<a href="#" id="selectOptions">
	<span></span>
	<span></span>
	<span></span>
</a>

<!--
<div class="filter-area">
	<div class="container">
		<div class="row">
			<div class="col-sm-4" id="teamSelectDiv">
			<div id="teamSelect" class="select" name="team"><div class="selected">BY TEAM</div> <div class="options hide"><input type="hidden" id="teamValue" name="region" value=""><div class="select-option" parent="team" action="team_filter" value="" thename="View All">View All</div><div class="select-option profile-plus-acumen" parent="team" action="team_filter" value="profile-plus-acumen" thename="View All">+Acumen</div><div class="select-option administration" parent="team" action="team_filter" value="administration" thename="View All">Administration</div><div class="select-option business-development" parent="team" action="team_filter" value="business-development" thename="View All">Business Development</div><div class="select-option communications-marketing" parent="team" action="team_filter" value="communications-marketing" thename="View All">Communications &amp; Marketing</div><div class="select-option finance" parent="team" action="team_filter" value="finance" thename="View All">Finance</div><div class="select-option impact" parent="team" action="team_filter" value="impact" thename="View All">Impact</div><div class="select-option investment-committee" parent="team" action="team_filter" value="investment-committee" thename="View All">Investment Committee</div><div class="select-option leadership" parent="team" action="team_filter" value="leadership" thename="View All">Leadership</div><div class="select-option legal" parent="team" action="team_filter" value="legal" thename="View All">Legal</div><div class="select-option operations" parent="team" action="team_filter" value="operations" thename="View All">Operations</div><div class="select-option portfolio" parent="team" action="team_filter" value="portfolio" thename="View All">Portfolio</div><div class="select-option strategic-partnerships" parent="team" action="team_filter" value="strategic-partnerships" thename="View All">Strategic Partnerships</div><div class="select-option talent" parent="team" action="team_filter" value="talent" thename="View All">Talent</div></div></div>			</div>
			<div class="col-sm-4" id="RegionDiv">
			<div id="regionSelect" class="select" name="region"><div class="selected">BY REGION</div><div class="options hide"><input type="hidden" id="regionValue" name="region" value=""><div class="select-option" parent="region" action="team_filter" value="" thename="View All">View All</div><div class="select-option" parent="region" action="team_filter" value="colombia" thename="Colombia">Colombia</div><div class="select-option" parent="region" action="team_filter" value="ghana" thename="Ghana">Ghana</div><div class="select-option" parent="region" action="team_filter" value="india" thename="India">India</div><div class="select-option" parent="region" action="team_filter" value="kenya" thename="Kenya">Kenya</div><div class="select-option" parent="region" action="team_filter" value="london" thename="London">London</div><div class="select-option" parent="region" action="team_filter" value="new-york" thename="New York">New York</div><div class="select-option" parent="region" action="team_filter" value="pakistan" thename="Pakistan">Pakistan</div><div class="select-option" parent="region" action="team_filter" value="san-francisco" thename="San Francisco">San Francisco</div></div></div>			</div>
			<div class="col-sm-4">
				<input type="text" placeholder="SEARCH BY NAME" id="searchbox" onfocus="this.placeholder = ''" onblur="this.placeholder = 'SEARCH BY NAME'">
				<button id="search"></button>
				<input type="hidden" name="action" id="actionValue"  value="team_filter">
				<input type="hidden" id="roleValue" name="role" value="staff">
				<input type="hidden" id="quantityValue" name="quanity" value="18">
			</div>
		</div>
	</div>
</div>-->
<div class="container">
	<div id="response" class="row">
		<div class="col-lg-6 col-xl-4 bio">
		<div class="hover-box-content" style="height:200px;">
							<div class="image" style="background: url(images/yaminee.jpeg); background-position: center center; background-size: cover; "></div>
						<div class="box-content" style="background-color:white;height:200px;" onmouseover="this.style.background='#0085c3';this.style.color='white';" onmouseout="this.style.background='white';this.style.color='black';">
								<br/><br/>					
								<p class="name" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yaminee <br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Balasubramanian</p>
				<p class="title" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Founder and Campus <br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Connect</p>
				
			</div>
		</div>
	
</div>

<div class="col-lg-6 col-xl-4 bio">
	<div class="hover-box-content">
							<div class="image" style="background: url(images/Shalini.jpeg); background-position: center center; background-size: cover;"></div>
						<div class="box-content" style="background-color:white;height:200px;" onmouseover="this.style.background='#0085c3';this.style.color='white';" onmouseout="this.style.background='white';this.style.color='black';">
													<br/><br/>	
								<p class="name" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shalini</p>
				<p class="title" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Founder</p>
				
			</div>
		</div>
	
</div>
<div class="col-lg-6 col-xl-4 bio">
		<div class="hover-box-content">
							<div class="image" style="background: url(images/Sharmila.jpg); background-position: center center; background-size: cover;"></div>
						<div class="box-content" style="background-color:white;height:200px;" onmouseover="this.style.background='#0085c3';this.style.color='white';" onmouseout="this.style.background='white';this.style.color='black';">
										<br/><br/>				
								<p class="name" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sharmila <br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Manikanta Dhas</p>
				<p class="title" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Manager-<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Operations</p>
				
			</div>
		</div>
	
</div>



<div class="col-lg-6 col-xl-4 bio" style="height:200px;">
		<div class="hover-box-content">
							<div class="image" style="background: url(images/Amrita.jpg); background-position: center center; background-size: cover;"></div>
						<div class="box-content" style="background-color:white;height:200px;" onmouseover="this.style.background='#0085c3';this.style.color='white';" onmouseout="this.style.background='white';this.style.color='black';">
									<br/><br/>					
								<p class="name" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Amrita Chakraborty</p>
				<p class="title" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Intern Developer</p>
				
			</div>
		</div>
	
</div>
<div class="col-lg-6 col-xl-4 bio">
<div class="hover-box-content">
							<div class="image" style="background: url(images/Shoba.jpeg); background-position: center center; background-size: cover;"></div>
						<div class="box-content" style="background-color:white;height:200px;" onmouseover="this.style.background='#0085c3';this.style.color='white';" onmouseout="this.style.background='white';this.style.color='black';">
									<br/><br/>					
								<p class="name" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shoba Ashok</p>
				<p class="title" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Campus Chemistry</p>
				
			</div>
		</div>
	
</div>
<div class="col-lg-6 col-xl-4 bio">
		<div class="hover-box-content">
							<div class="image" style="background: url(images/Anjana.jpeg); background-position: center center; background-size: cover;"></div>
						<div class="box-content" style="background-color:white;height:200px;" onmouseover="this.style.background='#0085c3';this.style.color='white';" onmouseout="this.style.background='white';this.style.color='black';">
									<br/><br/>					
								<p class="name" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Anjana Samuel</p>
				<p class="title" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Corporate<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Relations</p>
				
			</div>
		</div>
	
</div>
<div class="col-lg-6 col-xl-4 bio" style="height:200px;" style="background-color:white;">
		<div class="hover-box-content" style="background-color:white;">
							<div class="image" style="background: url(images/group.png); background-position: center center; background-size: cover;"></div>
						<div class="box-content" style="background-color:white;height:200px;" onmouseover="this.style.background='#0085c3';this.style.color='white';" onmouseout="this.style.background='white';this.style.color='black';">
										<br/><br/>			
								
				<p class="title" style="text-transform: uppercase;font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Industry Veterans</p>
				
			</div>
		</div>
	
</div>

<!--<div class="full-width text-center load-more-box"><button class="load-more btn primary">Load More<span><span> </button></div>-->	</div>
</div>





<div class="jumbotron full-bleed">
		<div class="full-hw" style="background: url(images/study2.jpeg); background-size: cover; background-position: center center;"></div>
	
  <div class="container">
    <div class="row">
      <div class="ml-auto col-md-12 justify--center float-right z-9 col-auto">
      	<div class="hero-content">
      		<span class="small-text" style="font-family:itc-avant-garde-gothic-std-bold-condensed;">Employment Opportunities</span>
      		<h2 class="text-white"  style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">We dream big and get things done.</h2>
          <div class="body_text"></div>
      		<div class="lead">
      		    				<a href="contactform.php" class="btn primary" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
    					Work With Us    					<span></span>
    				</a>
    			      		</div>
        </div>
      </div>
    </div>
  </div>
</div>
				<footer >
			<div class="container">
				<div class="row text-left">
					<div class="col-md-12">
						<h2 class="text-white" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Get Our Newsletter To Stay Up To Date</h2>
						<form class="form1" method='post' action="">
						<input type="email" name="emailid" placeholder="email here" required />
						<button name="submit"> SUBSCRIBE </button>
						</form>
						<?php
							error_reporting(0);
							include_once 'connect_db.php';
							if(isset($_SESSION['user'])!="")
							{
								header("Location: Team.php");
							}
							if(isset($_POST['submit']))
							{
								
					
								$email = mysql_real_escape_string($_POST['emailid']);
								$query=mysql_query("SELECT * FROM subscribers WHERE EmailId='".$email."'"); 
								$numrows=mysql_num_rows($query);  
								if($numrows!=0) 
								{	
									?>
									<script>alert('Already an existing subscriber !!! ');</script>
									<?php
								}	
								else								
								{
								 if(mysql_query("INSERT INTO subscribers(EmailId) VALUES('$email')"))
								{
									?>
									<script>alert('Successfully Subscribed !!! ');</script>
									<?php
								}
								else
								{
									?>
									<script>alert('error while submitting your details...');</script>
									<?php
								}
								}
							}
						?>
                        </div>
						<style>
						.form1{
							width:100%;
						height:50px;}
						form input{
							width:300px;
							height:50px;
							background-color:white;
							border:none;
							border-top-left-radius:5px;
						border-bottom-right-radius:5px;}
						form input[type="email"]{
							padding-left:10px;
							
						}
						button{
							height:55px;
							background-color:#999;
							color:#333;
							padding-left:10px;
							padding-right:10px;
							border:1px solid #333;
							border-top-left-radius:5px;
							border-bottom-right-radius:5px;
							transition: all0 0.5s ease-in-out;
						}
						button:hover{
							background-color:#333;
						color:#999;}
						</style>
					</div>
				</div>
				
				<div class="row bottom-section">
					<div class="col-md-2">
						<img src="images/CQlogo.png" alt="CQlogo" class="footer-logo" width="100" height="70"><br/><br/>
						<i class="fa fa-phone" aria-hidden="true" style="color:white;"></i>&nbsp;&nbsp;<font color="white">+91 9632283007</font>
					</div>
					<div class="col-md-10">
						<div class="topnav">
							<ul>
								
								<li>
									<a href="contactform.php" class="btn secondary" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
										<span></span>
										Contact Us
									</a>
								</li>
								<li class="social-button">
					                 <a href="https://www.facebook.com/CampusQuotient/?fref=nf" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
					            </li>
					            <li class="social-button">
					                <a href="https://twitter.com/CampusQuotient" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
					            </li>
					            <li class="social-button">
					                 <a href="https://www.youtube.com/channel/UC8O5Yr5n6qJ3JcigfOAN80g" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a>
					            </li>
								<li class="social-button">
					                 <a href="https://www.linkedin.com/company/campus-quotient" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
					            </li>
								<li class="social-button">
					                 <p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:160%;color:white;"><b>&nbsp;&nbsp;&nbsp;&nbsp;CAMPUS QUOTIENT FOUNDATION </b></p>
					            </li>
					        </ul>
						</div>
						
					</div>
				</div>
			</div>
		</footer>
		<span id="view-profile-overlay">
			<a href="#" class="close-profile">
				<svg width="82px" height="82px" viewBox="0 0 82 82" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Acumen-Website-v2-Final" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="8.-a)-3x-Team-Headshots-&amp;-Bios-Grid-02" transform="translate(-569.000000, -109.000000)" stroke="#FFFFFF">
            <g id="big-close-button" transform="translate(570.000000, 110.000000)">
                <g id="Group-2" transform="translate(40.000000, 40.000000) rotate(-315.000000) translate(-40.000000, -40.000000) translate(20.000000, 20.000000)" stroke-linecap="square">
                    <path d="M20,0.392156863 L20,39.6078431" id="Line"></path>
                    <path d="M0.392156863,20 L39.6078431,20" id="Line"></path>
                </g>
                <circle id="Oval-12" cx="40" cy="40" r="40"></circle>
            </g>
        </g>
    </g>
</svg>			</a>
		</span>
	</div><!-- End of #slideContent -->
</div><!-- End of #mainContainer -->

<div id="sidenavContainer" off-canvas="sidenav right shift">
	<div class="inner">       
    <a href="#" class="js-toggle-sidenav">
        <svg width="23px" height="21px" viewBox="0 0 23 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Acumen-Website-v2-Final" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="square">
        <g id="Navigation-1---Burger-Tray-B" transform="translate(-901.000000, -40.000000)" stroke="#FFFFFF">
            <g id="X" transform="translate(902.000000, 40.000000)">
                <path d="M0,0 L20.9632932,20.9632932" id="Line"></path>
                <path d="M0,20.9632932 L20.9632932,0" id="Line-Copy-2"></path>
            </g>
        </g>
    </g>
</svg>    </a>

    <div class="mobile-sideNav">
            
          
                  <div class="mobile-side"><ul id="menu-main-menu" class="nav navbar-nav" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="About" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu" >
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="About Us" href="AboutUs.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About Us</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Manifesto" href="Manifesto.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Manifesto</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Team" href="Team.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Team</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Partners" href="Partners.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Partners</a></li>
</ul>
</li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="Engage With Us" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Engage With Us <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu" >
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="Students" href="EngageWithUs.php#student" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Students</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Professors" href="EngageWithUs.php#professors" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Professors</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Corporate Partners" href="EngageWithUs.php#corporate" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Corporate Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Government of India" href="EngageWithUs.php#GOI" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Government of India</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Training Partners" href="EngageWithUs.php#training" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Training Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Volunteers" href="EngageWithUs.php#volunteers" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Volunteers</a></li>

	</ul>
</li><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="The Latest" href="Latest.php">Latest</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="Gallery" href="Gallery.php">Gallery</a></li>

</ul></div>    </div>
     <div class="bottom-section">
        <div class="links">
            <div class="link-item active">
                
                <div class="form-box">
                     <div class="class-area">
                        <div class="course-image" style="background: url(images/Section4.jpeg); background-position: center; background-size: cover;height:300px;"></div>
                        
							<a href="AboutUs.php" target="_blank" class="btn secondary" style="font-size:13px;">Add CQ courses to your curriculum</a>
                    </div>
                </div>
            </div>
			<div class="link-item">
                 <a href="contactform.php" class="text-box right">
                            Apply To Us                      </a>
            </div>
            <div class="link-item">
                <a href="Partners.php" class="text-box right">
                            Partner With Us                        </a>
            </div>
           
            <div class="link-item">
                <a href="donation.php" class="text-box right">
                           Other ways to give                     </a>
            </div>
                            
            
        </div>

        <div class="social_links">
                            <ul class="social-icons">
                                    <li class="social-button">
                        <a href="https://www.facebook.com/CampusQuotient/?fref=nf"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    </li>
                                    <li class="social-button">
                        <a href="https://twitter.com/CampusQuotient"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    </li>
                                    <li class="social-button">
                        <a href="https://www.youtube.com/channel/UC8O5Yr5n6qJ3JcigfOAN80g"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                    </li>
					<li class="social-button">
					                 <a href="https://www.linkedin.com/company/campus-quotient" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
					            </li>
                                </ul>
                    </div>
    </div>
</div></div>
<div id="profileContainer" off-canvas="view-profile right shift">
	<div id="profile"></div>
	<a href="#" class="close-profile">
		<svg width="82px" height="82px" viewBox="0 0 82 82" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Acumen-Website-v2-Final" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="8.-a)-3x-Team-Headshots-&amp;-Bios-Grid-02" transform="translate(-569.000000, -109.000000)" stroke="#FFFFFF">
            <g id="big-close-button" transform="translate(570.000000, 110.000000)">
                <g id="Group-2" transform="translate(40.000000, 40.000000) rotate(-315.000000) translate(-40.000000, -40.000000) translate(20.000000, 20.000000)" stroke-linecap="square">
                    <path d="M20,0.392156863 L20,39.6078431" id="Line"></path>
                    <path d="M0.392156863,20 L39.6078431,20" id="Line"></path>
                </g>
                <circle id="Oval-12" cx="40" cy="40" r="40"></circle>
            </g>
        </g>
    </g>
</svg>	</a>
</div>


<!-- JS -->
<script src='js/jquery-ui.min.js'></script>
<script src="js/acumen.min.js"></script>

<link rel='stylesheet' id='gravityformsmailchimp_form_settings-css'  href='css/form_settings.css' type='text/css' media='all' />
<script type='text/javascript' src='js/wp-embed.min.js'></script>
<script type='text/javascript' src='js/jquery.js'></script>
<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
<script type='text/javascript' src='js/jquery.json.min.js'></script>
<script type='text/javascript' src='js/gravityforms.min.js'></script>
<script type='text/javascript' src='js/placeholders.jquery.min.js'></script>

</body>
</html>
