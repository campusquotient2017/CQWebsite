<?php
include("includes/config.php");
include("includes/db.php");
$query="SELECT * FROM partners";
$partners = $db->query($query);
$query1="SELECT * FROM popup";
$popup = $db->query($query1);
?>
<!DOCTYPE html>
<html lang="en-US" prefix="og: http://ogp.me/ns#" class="no-js no-svg defaultHeader">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="IS INDIA'S WORKFORCE ENTERPRISE READY?">
  <link href="css/style.css" rel="stylesheet">
  <link href="fonts/font-awesome-css.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">


  <link rel="shortcut icon" href="images/CQlogo.png" />
   <meta name="twitter:card" content="summary" />
   <style>
.news-demo {
  background: #fff;
  padding: 20px;
}

.news-demo h1 {
  text-align: center;
  font-family: Arial, sans-serif;
  color: #777;
  margin-bottom: 40px;
}

.news-demo .p {
  text-align: center;
  font-family: Arial, sans-serif;
  font-size: 22px;
  margin-top: 70px;
}

.news-demo .p ~ p {
  margin-top: 0;
}

.news-demo .p a {
  text-decoration: underline;
}

.news-demo .p a:hover {
  color: red;
}
</style>
<link rel="stylesheet" href="css/vertical.news.slider.css?v=1.0">
  
<!-- This site is optimized with the Yoast SEO plugin v5.9.1 - https://yoast.com/wordpress/plugins/seo/ -->
<title>Campus Quotient | Homepage -</title>
<link rel="canonical" href="https://CampusQuotient.org" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Campus Quotient | Homepage -" />
<meta property="og:url" content="https://CampusQuotient.org/" />
<meta property="og:site_name" content="Campus Quotient" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Campus Quotient | Homepage -" />
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//s.w.org' />

		<style type="text/css">
		
		
@font-face{
	 font-family:itc-avant-garde-gothic-std-bold-condensed;
	 src:url("fonts/itc-avant-garde-gothic-std-bold-589572c7e9955.otf");
}
body{
font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;
}

@font-face{
	 font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;
	 src:url("fonts/itc-avant-garde-gothic-std-extra-light-5895708744eb6.otf");
}

img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-111977124-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-111977124-1');
</script>
<link rel='shortlink' href="images/CQlogo.png" />
</head>

<body class="home page-template page-template-t-homepage page-template-t-homepage-php page page-id-18768" >
  <div id="MainNavDiv" class="sidenavMoves">
  <nav class="navbar navbar-expand-lg navbar-light bg-white" id="mainNav">
    <div class="modal fade" id="myModal" data-backdrop="static" role="dialog" style="z-index:1050; width:100%">
    <div class="modal-dialog modal-lg modal-sm modal-md ">
    
      <!-- Modal content-->
      <div class="modal-content">
          
            <div class="modal-header" style="background-color:#009999;">
              <button style="height:20px;"type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body" style="background-image: url('images/4.jpg'); background-size: 100% 100%; height:500px;">
              <div class="container" style="color:black; text-align: center;  font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6; width:100%; height:100%">
                  <h1 style="align-content: center; font-size:40px;"><strong>Become an Industry Mentor!</strong></h1> 
                  <div>
                      <h4><b>Earn some money <i class="fa fa-inr"></i> this weekend!</b></h4>
                      <h4><b>Do something good this weekend!</b></h4>
                      <h4><b><i class="material-icons">call</i>Calling experienced professionals working in IT to help <br> transform colleges across India.</b></h4>
                      <h4><b><a href="mentor-main.php" style="color:white;"><i class="fa fa-hand-o-right"></i>Click</a> here to know how you can be part of this fulfilling journey.</b></h4>
                  </div>
              </div>
            </div>
      
    </div>
  </div> 
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){
        if(sessionStorage.getItem('#myModal')!== 'true'){
            $('#myModal').modal('show');
            sessionStorage.setItem('#myModal','true');
    }
    });
</script>
<script>
$(document).ready(function(){
    $("#modalbt").click(function(){
        $("#myModal").modal();
    });
});
</script>
    <div class="container">
      <a class="navbar-brand" href="index.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:100%;"><img src="images/CQlogo.png" alt="CQlogo"></a>
      <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button> -->

      <div class="collapse navbar-collapse" id="navbarsExample07">
        <div id="bs-example-navbar-collapse-1" class="collapse navbar-collapse">
		<ul id="menu-main-menu" class="nav navbar-nav" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
		<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="About" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu" >
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="About Us" href="AboutUs.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About Us</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Manifesto" href="Manifesto.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Manifesto</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Team" href="Team.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Team</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Partners" href="Partners.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Partners</a></li>
</ul>
</li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="Engage With Us" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Engage With Us <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu" >
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="Students" href="EngageWithUs.php#student" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Students</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Professors" href="EngageWithUs.php#professors" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Professors</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Corporate Partners" href="EngageWithUs.php#corporate" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Corporate Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Government of India" href="EngageWithUs.php#GOI" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Government of India</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Training Partners" href="EngageWithUs.php#training" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Training Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Volunteers" href="EngageWithUs.php#volunteers" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Volunteers</a></li>

	</ul>
</li><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="The Latest" href="Latest.php">Latest</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="Gallery" href="Gallery.php">Gallery</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="Blog" href="https://campusquotient109678000.wordpress.com/">Blog</a></li>
</ul></div>        </div>


        <div class="button-area" >
         
           <a href="mentor-main.php">
           <img title="Important Message!" style="width: 150px; height: 60px; margin-right: 30px;"  class="img-circle" src="images/hiring.jpg"></a>
           

          <a href="donation.php" target="_blank" class="btn primary heroDonateButton" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
            Contribute
            <span></span>
          </a>


         <button class="js-toggle-sidenav menu-btn">
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
    </div>
  </nav>
  <span id="navBorder"></span>
  <form id="headerSearchBox" class="form-inline my-md-0 search-area " method="get" action="https://CampusQuotient.org" role="search">
    <div class="inner">
      <div class="container">
        <a class="navbar-brand" href="index.php"><img src="images/CQlogo.png" alt="CQlogo"></a>

        <div class="searchBox" id="searchBox">
          <input class="form-control" type="search" placeholder="WHAT ARE YOU LOOKING FOR?" onfocus="this.placeholder = ''" onblur="this.placeholder = 'WHAT ARE YOU LOOKING FOR?'" value="" name="s" title="Search for:" aria-label="Search">
          <button class="icon-btn" type="submit" role="button">
            <svg width="22px" height="22px" viewBox="0 0 22 22" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Main-Nav-01" transform="translate(-1199.000000, -39.000000)">
            <g id="Search-icon" transform="translate(1200.000000, 40.000000)">
                <rect id="Rectangle-24" fill="#716B70" transform="translate(16.242641, 16.742641) rotate(45.000000) translate(-16.242641, -16.742641) " x="11.2426407" y="16.2426407" width="10" height="1"></rect>
                <circle id="Oval" stroke="#716B70" cx="7.5" cy="7.5" r="7.5"></circle>
            </g>
        </g>
    </g>
</svg>          </button>
        </div>

        <a class="search-close-btn" href="/"><svg width="23px" height="21px" viewBox="0 0 23 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    
</svg></a>
      </div>
    </div>
  </form>
</div>
<div id="stickySpacer"></div>

<div id="mainContainer" class="sidenavMoves">
  <div id="slideContent">

<div id="homeHero"></div>

<style>
.jumbotron{
	position: relative;
	overflow: hidden;
}

.hero-content{
	float: left;
	z-index: 10;
	font-family:AvantGardeLT-BookObliqueimport;

}
</style>



<div class="jumbotron hero-header" style="background: url(images/student-2052868_1920.jpg); background-size: cover; background-position: center center;">
  
  <div class="container">
    <div class="row">
      <div class="col-md-6 float-left z-9 align-self-center">
      	<div class="hero-content"  data-aos="fade-up" data-aos-anchor-placement="top-center" data-aos-once="true">
      		<div class="text-white h1"><p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6; "><strong style="font-family:itc-avant-garde-gothic-std-bold-condensed; ">IS INDIA'S <font style="COLOR:yellow;">WORKFORCE ENTERPRISE READY?</font> </strong></p>
</div>
      		<p class="lead">
      								<b><a href="contactform.php" class="btn primary" style="font-size:100%;font-family::itc-avant-garde-gothic-std-bold-condensed; color:white;">
						Join Us						<span></span>
					</a></b>
				      		</p>
        </div>
      </div>
	
    </div>
  </div>
  <a href="#aboutUs" id="scrollDown" class="js-scroll-trigger"><img src="images/scroll.png" alt="scroll"></a>
</div>
<div id="aboutUs" class="homepage-leftright-section">
					<div class="homepage-leftright greybg  right-image-first  " data-aos="fade-up" data-aos-anchor-placement="top-center" data-aos-once="true">
							
							<center><h1 style="font-family:itc-avant-garde-gothic-std-bold-condensed;color:#336699;"> NEWS</h1></center><br/>
							<div class="container">
							
								<div class="row">
									<div class="col-md-12">
										<div id="testimonial-slider" class="owl-carousel">
											<?php if($popup->num_rows >0) { 
											while($row = $popup->fetch_assoc()) {
											?>	<div class="testimonial">
												<div class="pic">
													<img src="<?php echo $row['logo']; ?>" style="max-width:80%;max-height:8  0%;">
												</div><br/>
												<div class="testimonial-profile">
													<h3 class="title" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6; "> <?php echo $row['title']; ?></h3><br/>
													
												</div>
												<p class="description" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6; ">
												   <?php echo $row['text']; ?> </p><br/>
											</div>
											<?php } } ?>
										</div>
									</div>
								</div>
							</div>
						<style>
						.testimonial{ margin: 0 20px 50px; }
						.testimonial .pic{
							display: inline-block;
							width: 400px;
							height: 150px;
							border-radius:0%;
							margin: 0 15px 15px 0;
						}
						.testimonial .pic img{
							width: 100%;
							height: auto;
							border-radius: 0%;
						}
						.testimonial .testimonial-profile{
							display: inline-block;
							position: relative;
							top: 15px;
						}
						.testimonial .title{
							display: block;
							font-size: 20px;
							font-weight: 600;
							color: #2f2f2f;
							text-transform: capitalize;
							margin: 0 0 7px 0;
						}
						.testimonial .post{
							display: block;
							font-size: 14px;
							color: #5d7aa7;
						}
						.testimonial .description{
							padding: 20px 22px;
							background: #1f487e;
							font-size: 15px;
							color: #fff;
							line-height: 25px;
							margin: 0;
							position: relative;
						}
						.testimonial .description:before,
						.testimonial .description:after{
							content: "";
							border-width: 18px 0 0 18px;
							border-style: solid;
							border-color: #5d7aa7 transparent transparent;
							position: absolute;
							bottom: -18px;
							left: 0;
						}
						.testimonial .description:after{
							border-width: 18px 18px 0 0;
							left: auto;
							right: 0;
						}
						.owl-theme .owl-controls{
							margin-top: 10px;
							margin-left: 30px;
						}
						.owl-theme .owl-controls .owl-buttons div{
							opacity: 0.8;
							background: #fff;
						}
						.owl-prev:before,
						.owl-next:before{
							content: "\f053";
							font-family: 'FontAwesome';
							font-size: 20px;
							color: #1f487e;
						}
						.owl-next:before{ content: "\f054"; }
						</style>
					</div>
				<div class="homepage-leftright greybg  right-image-first  " data-aos="fade-up" data-aos-anchor-placement="top-center" data-aos-once="true">
				<div class="container">
					<div class="row ">
						<div class="col-md-6 text-side align-self-center">
								<span class="pink-text small-text uppercase"></span>
								<h2 class="p1"><span style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;" ><strong style="font-family:itc-avant-garde-gothic-std-bold-condensed;"><font color="#0085c3">we create</font></strong> enterprise ready talents that enable india to meet its growing workforce demands</span></h2>
								<a href="Portfolio.php" class="btn primary" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
									See Our Portfolio									<span></span>
								</a>
						</div>
						<div class="col-md-6 image-side">
							<div class="">
								<img src="images/banner.jpg" alt="banner" class="">
							</div>
						</div>
					</div>
				</div>
			</div>
		
		
				<div class="homepage-leftright greybg  left-image-first  " data-aos="fade-up" data-aos-anchor-placement="top-center" data-aos-once="true">
				<div class="container">
					<div class="row ">
						<div class="col-md-6 text-side align-self-center">
								<h2 class="p1"><span style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"><strong style="font-family:itc-avant-garde-gothic-std-bold-condensed;"><font color="#0085c3">Our score card motivates</font></strong> and drives us</span></h2>
								<a href="SuccessFactor.php" class="btn primary" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
									Success Factors								<span></span>
								</a>
						</div>
						<div class="col-md-6 image-side">
							<div class="">
								<img src="images/team-386673__340.jpg" alt="team" class="">
							</div>
						</div>
					</div>
				</div>
			</div>
		
		
				<div class="homepage-leftright greybg  right-image-first  " data-aos="fade-up" data-aos-anchor-placement="top-center" data-aos-once="true">
				<div class="container">
					<div class="row ">
						<div class="col-md-6 text-side align-self-center">
								<span class="pink-text small-text uppercase" ></span>
								<h2 style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"><strong style="font-family:itc-avant-garde-gothic-std-bold-condensed;"><font color="#0085c3">Our experience and approach</font></strong> is what makes us a favourite school for an impactful change</h2>
								<a href="HowWeDoIt.php" class="btn primary" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
											How We Do It<span></span>
								</a>
						</div>
						<div class="col-md-6 image-side">
							<div class="">
								<img src="images/plant-2973636_1280.jpg" alt="plant" class="">
							</div>
						</div>
					</div>
				</div>
			</div>
		
		
				
		
		
		<span class="before"></span>
	<span class="after"></span>
</div>


<div class="partners" style="background-color:#f2f2f2;">
	<div class="container">
		<div class="row ">
			<div class="col-md-6 fadeInBlock animated">
				<div class="partner-logos add-carousel">
					<div class="logo-box ">
				<?php if($partners->num_rows >0) { 
				while($row = $partners->fetch_assoc()) {
				?>					
						<div class="col-md-4 image-box">
							<div class="">
								<img src="<?php echo $row['image']; ?>"class='full-width'>
							</div>
						 </div>	
				<?php } } ?>
					</div>	
						
				</div>
			</div>
			<div class="col-md-6 align-self-center fadeInBlock animated">
					<span class="text-white small-text uppercase" style="font-family:itc-avant-garde-gothic-std-bold-condensed;"><font color="#0085c3" size="6">Our Partners</font></span>
					<div class="h2 text-white" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"><font color="black">WE PARTNER WITH SOME OF THE INDUSTRY'S RECOGNIZED CORPORATES COMMITTED TO TACKLE UNEMPLOYMENT</font></div>
											<a href="contactform.php" class="btn primary" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
							Join Us							<span></span>
						</a>
								</div>
		</div>
	</div>
</div>

	


			<footer >
			<div class="container">
				<div class="row text-left">
					<div class="col-md-12">
						<h2 class="text-white" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Get Our Newsletter To Stay Up To Date</h2>
						<form class="form1" method='post' action="">
						<input type="email" name="emailid" placeholder="email here" required />
						<button name="submit"> SUBSCRIBE </button>
						</form>
						<?php
							error_reporting(0);
							include_once 'connect_db.php';
							if(isset($_SESSION['user'])!="")
							{
								header("Location: index.php");
							}
							if(isset($_POST['submit']))
							{
								
					
								$email = mysql_real_escape_string($_POST['emailid']);
								$query=mysql_query("SELECT * FROM subscribers WHERE EmailId='".$email."'"); 
								$numrows=mysql_num_rows($query);  
								if($numrows!=0) 
								{	
									?>
									<script>alert('Already an existing subscriber !!! ');</script>
									<?php
								}	
								else								
								{
								 if(mysql_query("INSERT INTO subscribers(EmailId) VALUES('$email')"))
								{
									?>
									<script>alert('Successfully Subscribed !!! ');</script>
									<?php
								}
								else
								{
									?>
									<script>alert('error while submitting your details...');</script>
									<?php
								}
								}
							}
						?>
                        </div>
						<style>
						.form1{
							
							width:100%;
						height:50px;}
						form input{
							width:300px;
							height:50px;
							background-color:white;
							border:none;
							border-top-left-radius:5px;
						border-bottom-right-radius:5px;}
						form input[type="email"]{
							padding-left:10px;
							
						}
						button{
							height:55px;
							background-color:#999;
							color:#333;
							padding-left:10px;
							padding-right:10px;
							border:1px solid #333;
							border-top-left-radius:5px;
							border-bottom-right-radius:5px;
							transition: all0 0.5s ease-in-out;
						}
						button:hover{
							background-color:#333;
						color:#999;}
						</style>
					</div>
				</div>
				
				<div class="row bottom-section">
					<div class="col-md-2">
						<img src="images/CQlogo.png" alt="CQlogo" class="footer-logo" width="100" height="70"><br/><br/>
						<i class="fa fa-phone" aria-hidden="true" style="color:white;"></i>&nbsp;&nbsp;<font color="white">+91 9632283007</font>
					</div>
					<div class="col-md-10">
						<div class="topnav">
							<ul>
								
								<li>
									<a href="contactform.php" class="btn secondary" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">
										<span></span>
										Contact Us
									</a>
								</li>
								<li class="social-button">
					                 <a href="https://www.facebook.com/CampusQuotient/?fref=nf" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
					            </li>
					            <li class="social-button">
					               <a href="https://twitter.com/CampusQuotient" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
					            </li>
					            <li class="social-button">
					                <a href="https://www.youtube.com/channel/UC8O5Yr5n6qJ3JcigfOAN80g" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a>
					            </li>
								<li class="social-button">
					              <a href="https://www.linkedin.com/company/campus-quotient" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
					            </li>
					            
								<li class="social-button">
					              <a href="https://campusquotient109678000.wordpress.com/" target="_blank"><i class="fa fa-wordpress" aria-hidden="true"></i></a>
					            </li>
								<li class="social-button" style="align:right;">
					                <p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:170%;color:white;"><b>&nbsp;&nbsp;&nbsp;&nbsp;CAMPUS QUOTIENT FOUNDATION </b></p>
					            </li>

					        </ul>
						</div>
						
					</div>
				</div>
			</div>
		</footer>
		<span id="view-profile-overlay">
			<a href="#" class="close-profile">
				<svg width="82px" height="82px" viewBox="0 0 82 82" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    
</svg>			</a>
		</span>
	</div><!-- End of #slideContent -->
</div><!-- End of #mainContainer -->

<div id="sidenavContainer" off-canvas="sidenav right shift">
	<div class="inner">       
    <a href="#" class="js-toggle-sidenav">
        <svg width="23px" height="21px" viewBox="0 0 23 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
      <g id="Acumen-Website-v2-Final" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="square">
        <g id="Navigation-1---Burger-Tray-B" transform="translate(-901.000000, -40.000000)" stroke="#FFFFFF">
            <g id="X" transform="translate(902.000000, 40.000000)">
                <path d="M0,0 L20.9632932,20.9632932" id="Line"></path>
                <path d="M0,20.9632932 L20.9632932,0" id="Line-Copy-2"></path>
            </g>
        </g>
    </g>
</svg>    </a>

    <div class="mobile-sideNav">
            
          
                  <div class="mobile-side"><ul id="menu-main-menu" class="nav navbar-nav" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="About" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu" >
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="About Us" href="AboutUs.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">About Us</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Manifesto" href="Manifesto.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Manifesto</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Team" href="Team.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Team</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Partners" href="Partners.php" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Partners</a></li>
</ul>
</li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18915" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-18915 dropdown"><a title="Engage With Us" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Engage With Us <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu" >
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-20132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20132"><a title="Students" href="EngageWithUs.php#student" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Students</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19542"><a title="Professors" href="EngageWithUs.php#professors" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Professors</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Corporate Partners" href="EngageWithUs.php#corporate" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Corporate Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Government of India" href="EngageWithUs.php#GOI" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Government of India</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19543"><a title="Training Partners" href="EngageWithUs.php#training" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Training Partners</a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-19739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19739"><a title="Volunteers" href="EngageWithUs.php#volunteers" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;">Volunteers</a></li>

	</ul>
</li><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="The Latest" href="Latest.php">Latest</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="Gallery" href="Gallery.php">Gallery</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-18917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18917"><a title="Blog" href="https://campusquotient109678000.wordpress.com/">Blog</a></li>
</ul>
</div>    
</div>
     <div class="bottom-section">
      <div class="links">
            <div class="link-item active">
                
                <div class="form-box">
                     <div class="class-area">
                        <div class="course-image" style="background: url(images/Section4.jpeg); background-position: center; background-size: cover; height:300px;"></div>
                        
							<a href="AboutUs.php" target="_blank" class="btn secondary" style="font-size:13px;">Add CQ courses to your curriculum</a>
                    </div>
                </div>
            </div>
			<div class="link-item">
                 <a href="contactform.php" class="text-box right" >
                            Apply To Us                      </a>
            </div>
            <div class="link-item">
                <a href="Partners.php" class="text-box right">
                            Partner With Us                        </a>
            </div>
            
            <div class="link-item">
                <a href="donation.php" class="text-box right">
                           Other ways to give                     </a>
            </div>
                            
            
        </div>

        <div class="social_links">
                            <ul class="social-icons">
                                    <li class="social-button">
                        <a href="https://www.facebook.com/CampusQuotient/?fref=nf"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    </li>
                                    <li class="social-button">
                        <a href="https://twitter.com/CampusQuotient "><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    </li>
                                    <li class="social-button">
                        <a href="https://www.youtube.com/channel/UC8O5Yr5n6qJ3JcigfOAN80g"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                    </li>
                                     <li class="social-button">
			<a href="https://www.linkedin.com/company/campus-quotient" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
		    </li>
                                     <li class="social-button">
	                <a href="https://campusquotient109678000.wordpress.com/" target="_blank"><i class="fa fa-wordpress" aria-hidden="true"></i></a>
		    </li>
                                </ul>
                    </div>
    </div>
</div>
</div>


<div id="profileContainer" off-canvas="view-profile right shift">
	<div id="profile"></div>
	<a href="#" class="close-profile">
		<svg width="82px" height="82px" viewBox="0 0 82 82" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    
</svg>	</a>
</div>


<!-- JS --><script type="text/javascript" src="js/main.js" charset="UTF-8"></script><script src="js/6e31837b67.js"></script><script src="js/jquery.min.js"></script><script type="text/javascript">window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/CampusQuotient.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.1"}};!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56794,8205,9794,65039],[55358,56794,8203,9794,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);</script><script type='text/javascript'>jQuery(document).ready(function($){gformInitSpinner( 17, 'images/spinner.gif' );jQuery('#gform_ajax_frame_17').load( function(){var contents = jQuery(this).contents().find('*').html();var is_postback = contents.indexOf('GF_AJAX_POSTBACK') >= 0;if(!is_postback){return;}var form_content = jQuery(this).contents().find('#gform_wrapper_17');var is_confirmation = jQuery(this).contents().find('#gform_confirmation_wrapper_17').length > 0;var is_redirect = contents.indexOf('gformRedirect(){') >= 0;var is_form = form_content.length > 0 && ! is_redirect && ! is_confirmation;if(is_form){jQuery('#gform_wrapper_17').html(form_content.html());if(form_content.hasClass('gform_validation_error')){jQuery('#gform_wrapper_17').addClass('gform_validation_error');} else {jQuery('#gform_wrapper_17').removeClass('gform_validation_error');}setTimeout( function() { /* delay the scroll by 50 milliseconds to fix a bug in chrome */  }, 50 );if(window['gformInitDatepicker']) {gformInitDatepicker();}if(window['gformInitPriceFields']) {gformInitPriceFields();}var current_page = jQuery('#gform_source_page_number_17').val();gformInitSpinner( 17, 'images/spinner.gif' );jQuery(document).trigger('gform_page_loaded', [17, current_page]);window['gf_submitting_17'] = false;}else if(!is_redirect){var confirmation_content = jQuery(this).contents().find('.GF_AJAX_POSTBACK').html();if(!confirmation_content){confirmation_content = contents;}setTimeout(function(){jQuery('#gform_wrapper_17').replaceWith(confirmation_content);jQuery(document).trigger('gform_confirmation_loaded', [17]);window['gf_submitting_17'] = false;}, 50);}else{jQuery('#gform_17').append(contents);if(window['gformRedirect']) {gformRedirect();}}jQuery(document).trigger('gform_post_render', [17, current_page]);} );} );</script><script type='text/javascript'> if(typeof gf_global == 'undefined') var gf_global = {"gf_currency_config":{"name":"U.S. Dollar","symbol_left":"$","symbol_right":"","symbol_padding":"","thousand_separator":",","decimal_separator":".","decimals":2},"base_url":"https:\/\/CampusQuotient.org\/wp-content\/plugins\/gravityforms","number_formats":[],"spinnerUrl":"https:\/\/CampusQuotient.org\/wp-content\/plugins\/gravityforms\/images\/spinner.gif"};jQuery(document).bind('gform_post_render', function(event, formId, currentPage){if(formId == 17) {if(typeof Placeholders != 'undefined'){Placeholders.enable();}} } );jQuery(document).bind('gform_post_conditional_logic', function(event, formId, fields, isInit){} );</script><script type='text/javascript'> jQuery(document).ready(function(){jQuery(document).trigger('gform_post_render', [17, 1]) } ); </script>	<script type='text/javascript'> if(typeof gf_global == 'undefined') var gf_global = {"gf_currency_config":{"name":"U.S. Dollar","symbol_left":"$","symbol_right":"","symbol_padding":"","thousand_separator":",","decimal_separator":".","decimals":2},"base_url":"https:\/\/CampusQuotient.org\/wp-content\/plugins\/gravityforms","number_formats":[],"spinnerUrl":"https:\/\/CampusQuotient.org\/wp-content\/plugins\/gravityforms\/images\/spinner.gif"};jQuery(document).bind('gform_post_render', function(event, formId, currentPage){if(formId == 8) {if(typeof Placeholders != 'undefined'){Placeholders.enable();}} } );jQuery(document).bind('gform_post_conditional_logic', function(event, formId, fields, isInit){} );</script><script type='text/javascript'> jQuery(document).ready(function(){jQuery(document).trigger('gform_post_render', [8, 1]) } ); </script>  
<script src='js/jquery-ui.min.js'></script>
<script src="js/acumen.min.js"></script>

<link rel='stylesheet' id='gravityformsmailchimp_form_settings-css'  href='css/form_settings.css' type='text/css' media='all' />
<script type='text/javascript' src='js/wp-embed.min.js'></script>
<script type='text/javascript' src='js/jquery.js'></script>
<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
<script type='text/javascript' src='js/jquery.json.min.js'></script>
<script type='text/javascript' src='js/gravityforms.min.js'></script>
<script type='text/javascript' src='js/placeholders.jquery.min.js'></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
 <script>
$(document).ready(function(){
    $("#testimonial-slider").owlCarousel({
        items:2,
        itemsDesktop:[1000,2],
        itemsDesktopSmall:[979,2],
        itemsTablet:[768,1],
        pagination:false,
        navigation:true,
        navigationText:["",""],
        autoPlay:true
    });
});</script>
</body>
</html>