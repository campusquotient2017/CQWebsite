<html>
    <head>
        <title>mentor_form_status</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/css?family=Anton|Fjalla+One|Ubuntu" rel="stylesheet">
        <link href="bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="bootstrap-3.3.7-dist/js/jquery-3.3.1.min.js" type="text/javascript"></script>
        <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js" type="text/javascript"></script>
    </head>
    <body>
                
        <?php
$link = mysqli_connect("localhost", "root", "campus@123","campusquotient");


$sql="INSERT INTO mentors (FULLNAME,CURRENTROLE,LANGUAGES,CITY,PHONE,EMAILID)

VALUES

('$_POST[1]','$_POST[2]','$_POST[3]','$_POST[4]','$_POST[5]','$_POST[6]')";
if (! $link->query($sql)) {
    // Oh no! The query failed. 
    echo "Sorry, the website is experiencing problems.";

    // Again, do not do this on a public site, but we'll show you how
    // to get the error information
    echo "Error: Our query failed to execute and here is why: \n";
    echo "Query: " . $sql . "\n";
    echo "Errno: " . $link->errno . "\n";
    echo "Error: " . $link->error . "\n";
    echo "<p><a href='index.php'>Click</a> here to go to the Homepage.</p>";
    exit;
}

echo "<div class='jumbotron jumbotron-fluid' style=' height:100%; background-color: #2C3E50; background-size: 100% 100%;'>";
    echo "<div class='container' style='text-align: center; color:white; font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;'>";
        echo "<i class='fa fa-check-square' style='font-size: 100px;'></i>";
        echo "<h1><strong>Thank You!</strong></h1>";
        echo "<p>The form was submitted successfully.</p>";
        echo "<p><a href='index.php'>Click</a> here to go to the Homepage.</p>";
    echo "</div>";
echo "</div>";            

mysqli_close($link);
?>        
    </body>
</html>


