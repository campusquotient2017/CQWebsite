<?php
include("includes/header.php");
$search = $_GET['search'];
$query="SELECT * FROM posts WHERE (title LIKE '%$search%') or (body LIKE '%$search%') ";
$posts = $db->query($query);
?>
			<br/>
			<blockquote>Search Results</blockquote>

<?php if($posts->num_rows >0) { 
	  while($row = $posts->fetch_assoc()) {
		  ?>
          <div class="blog-post">
            <h2 class="blog-post-title" style="font-family:itc-avant-garde-gothic-std-bold-condensed;"><a href=""><?php echo $row['title']; ?></a></h2>
            <p class="blog-post-meta" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:15px;"><?php echo $row['date']; ?> <a href="#"><?php echo $row['author']; ?></a></p>
			<div class="row">
			<div class="col-md-6">
			<img src="<?php echo $row['picture']; ?>"  height="74%" width="100%"/>
			</div>
            <div class="col-md-6"><p style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:15px;"><?php $body = $row['body'];
					echo substr($body,0,300),"...";			?></p></div></div><br/>
					<?php $var = $row['id']; ?>
          <a href="CQBlog.php?varname=<?php echo $var ?>" class="btn btn-primary" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:20px;"> READ MORE </a></div><!-- /.blog-post -->
	  <?php } } else { echo " no result found"; } ?><br/>
	  <a href="Latest.php" class="btn btn-primary" style="font-family:itc-avant-garde-gothic-std-extra-light-5895708744eb6;font-size:20px;"> GO BACK </a>

	 
        </div><!-- /.blog-main -->
<?php
include("includes/sidebar.php");
?><?php
include("includes/footer.php");
?>
